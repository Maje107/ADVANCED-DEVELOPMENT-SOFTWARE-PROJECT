from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.dashboard_home, name='home'),
    path('login/', views.dashboard_login, name='login'),
    path('logout/', views.dashboard_logout, name='logout'),

    path('users/', views.dashboard_users, name='users'),
    path('users/create/', views.dashboard_users_create, name='users_create'),
    path('users/<int:user_id>/edit/', views.dashboard_users_edit, name='users_edit'),
    path('users/<int:user_id>/delete/', views.dashboard_users_delete, name='users_delete'),

    path('resources/', views.dashboard_resources, name='resources'),
    path('resources/create/', views.dashboard_resources_create, name='resources_create'),
    path('resources/<int:resource_id>/edit/', views.dashboard_resources_edit, name='resources_edit'),
    path('resources/<int:resource_id>/delete/', views.dashboard_resources_delete, name='resources_delete'),
]
