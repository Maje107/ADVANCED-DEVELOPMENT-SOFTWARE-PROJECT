from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count
from django.http import JsonResponse
from users.models import User
from resources.models import Resource


def dashboard_login(request):
    if request.user.is_authenticated:
        return redirect('dashboard:home')

    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, email=email, password=password)
        if user:
            login(request, user)
            next_url = request.GET.get('next', 'dashboard:home')
            return redirect(next_url)
        else:
            messages.error(request, 'Invalid email or password')

    return render(request, 'dashboard/login.html')


def dashboard_logout(request):
    logout(request)
    return redirect('dashboard:login')


@login_required
def dashboard_home(request):
    total_users = User.objects.count()
    total_students = User.objects.filter(role='student').count()
    total_lecturers = User.objects.filter(role='lecturer').count()
    total_admins = User.objects.filter(role='admin').count()
    total_resources = Resource.objects.count()

    resources_by_type = Resource.objects.values('type').annotate(
        count=Count('id')
    ).order_by('type')

    resources_by_type_labels = [r['type'] for r in resources_by_type]
    resources_by_type_data = [r['count'] for r in resources_by_type]

    recent_users = User.objects.order_by('-created_at')[:5]
    recent_resources = Resource.objects.order_by('-created_at')[:5]

    context = {
        'total_users': total_users,
        'total_students': total_students,
        'total_lecturers': total_lecturers,
        'total_admins': total_admins,
        'total_resources': total_resources,
        'resources_by_type_labels': resources_by_type_labels,
        'resources_by_type_data': resources_by_type_data,
        'recent_users': recent_users,
        'recent_resources': recent_resources,
    }
    return render(request, 'dashboard/home.html', context)


@login_required
def dashboard_users(request):
    users = User.objects.all().order_by('-created_at')
    role_filter = request.GET.get('role', '')
    search = request.GET.get('search', '')

    if role_filter:
        users = users.filter(role=role_filter)
    if search:
        users = users.filter(
            full_name__icontains=search
        ) | users.filter(
            email__icontains=search
        ) | users.filter(
            student_number__icontains=search
        )

    context = {
        'users': users,
        'role_filter': role_filter,
        'search': search,
    }
    return render(request, 'dashboard/users.html', context)


@login_required
def dashboard_users_create(request):
    if request.user.role != 'admin':
        messages.error(request, 'Admin access required')
        return redirect('dashboard:users')

    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        student_number = request.POST.get('student_number') or None
        password = request.POST.get('password')
        role = request.POST.get('role', 'student')

        if not all([full_name, email, password]):
            messages.error(request, 'Full name, email, and password are required')
        else:
            try:
                User.objects.create_user(
                    full_name=full_name,
                    email=email,
                    student_number=student_number,
                    password=password,
                    role=role,
                )
                messages.success(request, 'User created successfully')
                return redirect('dashboard:users')
            except Exception as e:
                messages.error(request, f'Error creating user: {str(e)}')

    return render(request, 'dashboard/user_form.html', {'mode': 'create'})


@login_required
def dashboard_users_edit(request, user_id):
    if request.user.role != 'admin':
        messages.error(request, 'Admin access required')
        return redirect('dashboard:users')

    user = get_object_or_404(User, id=user_id)

    if request.method == 'POST':
        user.full_name = request.POST.get('full_name', user.full_name)
        user.student_number = request.POST.get('student_number') or None
        user.role = request.POST.get('role', user.role)
        new_password = request.POST.get('password')

        if new_password:
            user.set_password(new_password)

        try:
            user.save()
            messages.success(request, 'User updated successfully')
            return redirect('dashboard:users')
        except Exception as e:
            messages.error(request, f'Error updating user: {str(e)}')

    return render(request, 'dashboard/user_form.html', {'mode': 'edit', 'user': user})


@login_required
def dashboard_users_delete(request, user_id):
    if request.user.role != 'admin':
        messages.error(request, 'Admin access required')
        return redirect('dashboard:users')

    if request.user.id == user_id:
        messages.error(request, 'You cannot delete your own account')
        return redirect('dashboard:users')

    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        user.delete()
        messages.success(request, 'User deleted successfully')
        return redirect('dashboard:users')

    return render(request, 'dashboard/user_delete.html', {'user': user})


@login_required
def dashboard_resources(request):
    resources = Resource.objects.all().order_by('-created_at')
    type_filter = request.GET.get('type', '')
    search = request.GET.get('search', '')

    if type_filter:
        resources = resources.filter(type=type_filter)
    if search:
        resources = resources.filter(
            name__icontains=search
        ) | resources.filter(
            location__icontains=search
        ) | resources.filter(
            description__icontains=search
        )

    context = {
        'resources': resources,
        'type_filter': type_filter,
        'search': search,
        'type_choices': Resource.TYPE_CHOICES,
    }
    return render(request, 'dashboard/resources.html', context)


@login_required
def dashboard_resources_create(request):
    if request.user.role not in ('admin', 'lecturer'):
        messages.error(request, 'Admin or Lecturer access required')
        return redirect('dashboard:resources')

    if request.method == 'POST':
        name = request.POST.get('name')
        resource_type = request.POST.get('type')
        location = request.POST.get('location') or None
        capacity = request.POST.get('capacity') or None
        description = request.POST.get('description') or None

        if not all([name, resource_type]):
            messages.error(request, 'Name and type are required')
        else:
            try:
                Resource.objects.create(
                    name=name,
                    type=resource_type,
                    location=location,
                    capacity=capacity if capacity else None,
                    description=description,
                )
                messages.success(request, 'Resource created successfully')
                return redirect('dashboard:resources')
            except Exception as e:
                messages.error(request, f'Error creating resource: {str(e)}')

    return render(request, 'dashboard/resource_form.html', {
        'mode': 'create',
        'type_choices': Resource.TYPE_CHOICES,
    })


@login_required
def dashboard_resources_edit(request, resource_id):
    if request.user.role not in ('admin', 'lecturer'):
        messages.error(request, 'Admin or Lecturer access required')
        return redirect('dashboard:resources')

    resource = get_object_or_404(Resource, id=resource_id)

    if request.method == 'POST':
        resource.name = request.POST.get('name', resource.name)
        resource.type = request.POST.get('type', resource.type)
        resource.location = request.POST.get('location') or None
        capacity = request.POST.get('capacity')
        resource.capacity = capacity if capacity else None
        resource.description = request.POST.get('description') or None

        try:
            resource.save()
            messages.success(request, 'Resource updated successfully')
            return redirect('dashboard:resources')
        except Exception as e:
            messages.error(request, f'Error updating resource: {str(e)}')

    return render(request, 'dashboard/resource_form.html', {
        'mode': 'edit',
        'resource': resource,
        'type_choices': Resource.TYPE_CHOICES,
    })


@login_required
def dashboard_resources_delete(request, resource_id):
    if request.user.role not in ('admin', 'lecturer'):
        messages.error(request, 'Admin or Lecturer access required')
        return redirect('dashboard:resources')

    resource = get_object_or_404(Resource, id=resource_id)
    if request.method == 'POST':
        resource.delete()
        messages.success(request, 'Resource deleted successfully')
        return redirect('dashboard:resources')

    return render(request, 'dashboard/resource_delete.html', {'resource': resource})
