from rest_framework import serializers
from .models import Resource


class ResourceCreateSerializer(serializers.ModelSerializer):
    name = serializers.CharField(min_length=2, max_length=100)
    type = serializers.CharField()
    capacity = serializers.IntegerField(min_value=1, required=False, allow_null=True)

    class Meta:
        model = Resource
        fields = ('name', 'type', 'location', 'capacity', 'description')

    def validate_type(self, value):
        valid_types = [t[0] for t in Resource.TYPE_CHOICES]
        if value not in valid_types:
            raise serializers.ValidationError(
                f'Invalid resource type. Must be one of: {", ".join(valid_types)}'
            )
        return value


class ResourceUpdateSerializer(serializers.ModelSerializer):
    name = serializers.CharField(min_length=2, max_length=100, required=False)
    type = serializers.CharField(required=False)
    capacity = serializers.IntegerField(min_value=1, required=False, allow_null=True)

    class Meta:
        model = Resource
        fields = ('name', 'type', 'location', 'capacity', 'description')

    def validate_type(self, value):
        valid_types = [t[0] for t in Resource.TYPE_CHOICES]
        if value not in valid_types:
            raise serializers.ValidationError(
                f'Invalid resource type. Must be one of: {", ".join(valid_types)}'
            )
        return value


class ResourceResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = ('id', 'name', 'type', 'location', 'capacity', 'description', 'created_at')
        read_only_fields = fields


class AvailabilityResponseSerializer(serializers.Serializer):
    resource_id = serializers.IntegerField()
    date = serializers.CharField()
    available = serializers.BooleanField()
    note = serializers.CharField()
