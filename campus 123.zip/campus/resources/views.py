from rest_framework import status, generics, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import Resource
from .serializers import (
    ResourceCreateSerializer,
    ResourceUpdateSerializer,
    ResourceResponseSerializer,
    AvailabilityResponseSerializer,
)
from users.permissions import IsAdmin


class HealthCheck(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        return Response({
            'service': 'inventory-service',
            'status': 'ok',
        })


class ResourceListView(generics.ListAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = ResourceResponseSerializer

    def get_queryset(self):
        queryset = Resource.objects.all()
        resource_type = self.request.query_params.get('type')
        location = self.request.query_params.get('location')
        search = self.request.query_params.get('search')

        if resource_type:
            queryset = queryset.filter(type=resource_type)
        if location:
            queryset = queryset.filter(location__icontains=location)
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(description__icontains=search)
            )
        return queryset


class ResourceCreateView(APIView):
    permission_classes = [IsAdmin]

    def post(self, request):
        serializer = ResourceCreateSerializer(data=request.data)
        if serializer.is_valid():
            resource = serializer.save()
            return Response(
                ResourceResponseSerializer(resource).data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_422_UNPROCESSABLE_ENTITY)


class ResourceDetailView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, resource_id):
        try:
            resource = Resource.objects.get(id=resource_id)
        except Resource.DoesNotExist:
            return Response(
                {'detail': 'Resource not found'},
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(ResourceResponseSerializer(resource).data)


class ResourceUpdateView(APIView):
    permission_classes = [IsAdmin]

    def put(self, request, resource_id):
        try:
            resource = Resource.objects.get(id=resource_id)
        except Resource.DoesNotExist:
            return Response(
                {'detail': 'Resource not found'},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = ResourceUpdateSerializer(resource, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(ResourceResponseSerializer(resource).data)
        return Response(serializer.errors, status=status.HTTP_422_UNPROCESSABLE_ENTITY)

    def delete(self, request, resource_id):
        try:
            resource = Resource.objects.get(id=resource_id)
        except Resource.DoesNotExist:
            return Response(
                {'detail': 'Resource not found'},
                status=status.HTTP_404_NOT_FOUND,
            )
        resource.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class AvailabilityView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, resource_id):
        try:
            resource = Resource.objects.get(id=resource_id)
        except Resource.DoesNotExist:
            return Response(
                {'detail': 'Resource not found'},
                status=status.HTTP_404_NOT_FOUND,
            )

        date = request.query_params.get('date', '')
        if not date:
            return Response(
                {'detail': 'date query parameter is required (YYYY-MM-DD)'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        data = {
            'resource_id': resource_id,
            'date': date,
            'available': True,
            'note': 'STUB: Booking Service integration pending (Phase 2). This does not yet reflect real bookings.',
        }
        return Response(AvailabilityResponseSerializer(data).data)
