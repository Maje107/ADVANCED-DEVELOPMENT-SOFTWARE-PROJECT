from django.db import models
from django.utils import timezone


class Resource(models.Model):
    TYPE_CHOICES = (
        ('room', 'Room'),
        ('lab', 'Lab'),
        ('equipment', 'Equipment'),
        ('sports_facility', 'Sports Facility'),
    )

    name = models.CharField(max_length=100)
    type = models.CharField(max_length=30, choices=TYPE_CHOICES, db_index=True)
    location = models.CharField(max_length=255, null=True, blank=True)
    capacity = models.PositiveIntegerField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        db_table = 'resources'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.name} ({self.get_type_display()})'
