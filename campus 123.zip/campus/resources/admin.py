from django.contrib import admin
from .models import Resource


@admin.register(Resource)
class ResourceAdmin(admin.ModelAdmin):
    list_display = ('name', 'type', 'location', 'capacity', 'created_at')
    list_filter = ('type', 'location')
    search_fields = ('name', 'location', 'description')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)

    fieldsets = (
        (None, {'fields': ('name', 'type')}),
        ('Details', {'fields': ('location', 'capacity', 'description')}),
        ('Metadata', {'fields': ('created_at',)}),
    )
