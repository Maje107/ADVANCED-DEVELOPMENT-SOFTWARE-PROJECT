from django.urls import path
from . import views

app_name = 'resources'

urlpatterns = [
    path('health', views.HealthCheck.as_view(), name='health'),
    path('', views.ResourceListView.as_view(), name='list'),
    path('create', views.ResourceCreateView.as_view(), name='create'),
    path('<int:resource_id>', views.ResourceDetailView.as_view(), name='detail'),
    path('<int:resource_id>/update', views.ResourceUpdateView.as_view(), name='update'),
    path('<int:resource_id>/availability', views.AvailabilityView.as_view(), name='availability'),
]
