from rest_framework import status, generics, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.conf import settings
from .models import User
from .serializers import (
    RegisterSerializer,
    LoginSerializer,
    UserResponseSerializer,
    TokenResponseSerializer,
)


class HealthCheck(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        return Response({
            'service': 'auth-service',
            'status': 'ok',
        })


class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            try:
                user = serializer.save()
                return Response(
                    UserResponseSerializer(user).data,
                    status=status.HTTP_201_CREATED,
                )
            except Exception as e:
                if 'unique' in str(e).lower() or 'Duplicate' in str(e):
                    return Response(
                        {'detail': 'Email or student number already registered'},
                        status=status.HTTP_409_CONFLICT,
                    )
                raise
        return Response(serializer.errors, status=status.HTTP_422_UNPROCESSABLE_ENTITY)


class LoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            refresh = RefreshToken.for_user(user)
            access_token_lifetime = settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME']
            data = {
                'access_token': str(refresh.access_token),
                'refresh_token': str(refresh),
                'token_type': 'bearer',
                'expires_in_minutes': int(access_token_lifetime.total_seconds() // 60),
                'user': UserResponseSerializer(user).data,
            }
            return Response(data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_401_UNAUTHORIZED)


class MeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserResponseSerializer(request.user).data)
