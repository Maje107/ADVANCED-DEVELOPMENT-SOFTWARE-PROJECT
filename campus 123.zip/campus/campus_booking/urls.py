from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('dashboard/', include('dashboard_app.urls', namespace='dashboard')),
    path('api/auth/', include('users.urls', namespace='users')),
    path('api/resources/', include('resources.urls', namespace='resources')),
    path('', include('dashboard_app.urls', namespace='dashboard_root')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
